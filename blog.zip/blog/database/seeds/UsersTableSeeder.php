<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = App\User::create([
                'name'=> 'Bongani Mondlane',
                'email'=> 'bongani@coolli.co.za',
                'password'=> bcrypt('password'),
                'admin'=> 1
            
            ]);
        
        App\Profile::create([
            
            'user_id' => $user->id,
            'about' => 'I am the admin here, I do anything I want.',
            'facebook' => 'facebook.com',
            'youtube' => 'youtube.com',
            'avatar' => 'uploads/avatars/about-us.png'
            
        ]);
    }
}
