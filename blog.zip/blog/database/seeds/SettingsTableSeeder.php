<?php

use Illuminate\Database\Seeder;

class SettingsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        \App\Setting::create([
            'site_name' => 'Neezy',
            'address' => 'Ndumiso Mondlane',
            'contact_number' => '0728370270',
            'contact_email' => 'neezy@neezy.co.za'
            
            
        ]);
    }
}
