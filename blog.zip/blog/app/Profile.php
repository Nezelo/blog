<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * 
 * @author Bongani.Mondlane
 *
 */
class Profile extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['user_id', 'avatar', 'youtube', 'facebook', 'about'];
    
    /**
     * Profile and User relationship.
     * A profile belongs to a single user.
     * 
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User');
    }
}
