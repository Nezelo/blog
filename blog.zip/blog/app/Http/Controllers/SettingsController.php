<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use Illuminate\Support\Facades\Session;

/**
 * 
 * @author Bongani.Mondlane
 *
 */
class SettingsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }
    
    /**
     * Update the specified resource in storage.
     *  
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update()
    {
        //Validates request information
        $this->validate(request(), [
            'site_name' => 'required',
            'contact_number' => 'required',
            'contact_email' => 'required',
            'address' => 'required',
        ]);
        
        $setting = Setting::first();
        
        $setting->site_name = request()->site_name;
        $setting->contact_number = request()->contact_number;
        $setting->contact_email = request()->contact_email;
        $setting->address = request()->address;
        
        $setting->save();
        
        Session::flash('success', 'Blog settings has been updated successfully.');
        
        return redirect()->back();
    }
    
    /**
     * Display a listing of the resource.
     * 
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function index()
    {
        return view('admin.settings.setting')->with('setting', Setting::first());
    }
}
