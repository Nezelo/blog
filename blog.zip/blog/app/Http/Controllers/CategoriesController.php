<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

/**
 * 
 * @author Bongani.Mondlane
 *
 */
class CategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.categories.index')->with('categories', Category::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.categories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Validate the request data.
        $this->validate($request, [
            
            'name' => 'required|max:255'
        ]);
        
        //Creates a new catrgory and save it in the database.
        $category = new Category;
        $category->name = $request->name;
        $category->save();
        
        //Sets a success session.
        Session::flash('success', 'You Successfully Created a Category');
        
        return redirect()->route('categories');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Find a category from the database table.
        $category = Category::find($id);
        return view('admin.categories.edit')->with('category', $category);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Finds and update category information.
        $category = Category::find($id);
        $category->name = $request->name;
        $category->save();
        
        //Sets a success session.
        Session::flash('success', 'You Successfully Updated a Category');
        
        return redirect()->route('categories');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Finds a category.
        $category = Category::find($id);
        
        //Permanately delete posts that to the category.
        foreach ($category->posts as $post)
        {
            $post->forceDelete();    
        }
        
        //Deletes the category.
        $category->delete();
        
        //Sets a success session.
        Session::flash('success', 'You Successfully Deleted a Category');
        
        return redirect()->route('categories');
    }
}
