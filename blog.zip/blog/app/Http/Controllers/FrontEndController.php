<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\Category;
use App\Post;
use App\Tag;

/**
 * 
 * @author Bongani.Mondlane
 *
 */
class FrontEndController extends Controller
{
    /**
     * Display a posts
     * 
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function index()
    {
        
        return view('index')
                        ->with('title', Setting::first()->site_name)
                        ->with('categories', Category::take(5)->get())
                        ->with('latestPost', Post::orderBy('created_at', 'desc')->first())
                        ->with('secondPost', Post::orderBy('created_at', 'desc')->skip(1)->take(1)->first())
                        ->with('thirdPost', Post::orderBy('created_at', 'desc')->skip(2)->take(1)->first())
                        ->with('setting', Setting::first())
                        ->with('postCategories', Category::all());
    }
    
    /**
     *  Display a single post.
     *  
     * @param string $slug
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function singlePost($slug)
    {
        //Find the post from the database.
        $post = Post::where('slug', $slug)->first();
        
        //The next and previous post.
        $next_id = Post::where('id', '>', $post->id)->min('id');
        $prev_id = Post::where('id', '<', $post->id)->max('id');
        
        
        return view('single')->with('post', $post)
                             ->with('title', $post->title)
                             ->with('categories', Category::take(5)->get())
                             ->with('setting', Setting::first())
                             ->with('next', Post::find($next_id))
                             ->with('prev', Post::find($prev_id))
                             ->with('tags', Tag::all());
    }
    
    /**
     *  Display a category.
     *  
     * @param integer $id
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function category($id)
    {
        $category = Category::find($id);
        
        return view('category')->with('category', $category)
                               ->with('title', $category->name)
                               ->with('categories', Category::take(5)->get())
                               ->with('setting', Setting::first());
    }
    
    /**
     * Display a tag.
     *  
     * @param integer $id
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function tag($id)
    {
        $tag = Tag::find($id);
        
        return view('tag')->with('tag', $tag)
                          ->with('title', $tag->tag)
                          ->with('categories', Category::take(5)->get())
                          ->with('setting', Setting::first());
    }
    
    /**
     * Display search results
     * 
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function results()
    {
        $posts = Post::where('title', 'like', '%' . request('query') . '%')->get();
        
        return view('results')->with('posts', $posts)
                              ->with('title', 'Search Results : ' . request('query'))
                              ->with('categories', Category::take(5)->get())
                              ->with('setting', Setting::first())
                              ->with('query',  request('query'));
    }
}
