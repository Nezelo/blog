<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * 
 * @author Bongani.Mondlane
 *
 */
class Post extends Model
{
    use SoftDeletes;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'title', 'content', 'featured', 'category_id', 'slug', 'user_id'
    ];
    
    protected $dates = ['deleted_at'];
    
    /**
     * Assets featured attribute.
     * 
     * @param string $featured
     * @return string
     */
    public function getFeaturedAttribute($featured)
    {
        return asset($featured);
        
    }
    
    /**
     * Post and Tag relationship.
     * A post belongs to many tags.
     * 
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function tags()
    {
        return $this->belongsToMany('App\Tag');
    }
    
    /**
     * Post and Category relationship.
     * A single post belongs to a single category.
     * 
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function category()
    {
        return $this->belongsTo('App\category');
    }
    
    /**
     * Post and User relationship.
     * A post belongs to a single user.
     * 
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User');
    }
    
}
