<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * 
 * @author Bongani.Mondlane
 *
 */
class Tag extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['tag']; 
    
    /**
     * Tags and Post relationship.
     * A tag belongs to many posts.
     * 
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function posts()
    {
        return $this->belongsToMany('App\Post');
    }
}
