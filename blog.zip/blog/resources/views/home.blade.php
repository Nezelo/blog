@extends('layouts.app')

@section('content')

<div class="col-lg-3">

	<div class="panel panel-info">
		<div class="panel-heading text-center">
			PUBLISHED POSTS
		</div>
		
		<div class="panel-body text-center">
			<h1 class="text-center">{{ $post_cout }}</h1>
		</div>
		
	</div>
	<div class="panel panel-danger">
		<div class="panel-heading text-center">
			TRASHED OSTS
		</div>
		
		<div class="panel-body text-center">
			<h1 class="text-center">8956</h1>
		</div>
		
	</div>
	<div class="panel panel-info">
		<div class="panel-heading text-center">
			CATEGORIES
		</div>
		
		<div class="panel-body text-center">
			<h1 class="text-center">8956</h1>
		</div>
		
	</div>
 
</div>

@endsection
