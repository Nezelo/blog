@extends('layouts.app')

@section('content')

	@if(count($errors) > 0)
	@endif
	<div class="panel panel-default">
	
		<div class="panel-heading">
			Edit Blog Setting
		</div>
		
		<div class="panel-body">
		
			<form action="{{ route('settings.update')}}" method="POST">
				{{ csrf_field() }}
				
				<div class="form-group {{ $errors->has('site_name') ? ' has-error' : '' }}">
					<label for="site_name">Site Name</label>
					<input  type="text" name="site_name" value="{{ $setting->site_name }}" class="form-control">
					@if ($errors->has('"site_name"'))
                        <span class="help-block">
                            <strong>{{ $errors->first('site_name') }}</strong>
                        </span>
                    @endif
				</div>
				
				
				<div class="form-group {{ $errors->has('address') ? ' has-error' : '' }}">
					<label for="address">Address</label>
					<input  type="text" name="address" value="{{ $setting->address }}" class="form-control">
					@if ($errors->has('"address"'))
                        <span class="help-block">
                            <strong>{{ $errors->first('address') }}</strong>
                        </span>
                    @endif
				</div>
				
				<div class="form-group {{ $errors->has('contact_number') ? ' has-error' : '' }}">
					<label for="address">Contact Number</label>
					<input  type="text" name="contact_number" value="{{ $setting->contact_number }}" class="form-control">
					@if ($errors->has('"contact_number"'))
                        <span class="help-block">
                            <strong>{{ $errors->first('contact_number') }}</strong>
                        </span>
                    @endif
				</div>
				
				
				<div class="form-group {{ $errors->has('contact_email') ? ' has-error' : '' }}">
					<label for="address">Contact Email</label>
					<input  type="email" name="contact_email" value="{{ $setting->contact_email }}" class="form-control">
					@if ($errors->has('"contact_email"'))
                        <span class="help-block">
                            <strong>{{ $errors->first('contact_email') }}</strong>
                        </span>
                    @endif
				</div>
				
				
				
				<div class="form-group">
					<div class="text-center">
						<button class="btn btn-success" type="submit">Update site settings</button>
					</div>
				</div>
				
				
			</form>
		</div>
	
	</div>
@stop