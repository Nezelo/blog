@extends('layouts.app')

@section('content')

	@if(count($errors) > 0)
	@endif
	<div class="panel panel-default offset-md-4">
	
		<div class="panel-heading">
			Create a new post
		</div>
		
		<div class="panel-body">
		
			<form action="{{ route('post.store')}}" method="POST" enctype="multipart/form-data">
				{{ csrf_field() }}
				
				<div class="form-group {{ $errors->has('title') ? ' has-error' : '' }}">
					<label for="title">Title</label>
					<input  type="text" name="title" class="form-control">
					@if ($errors->has('title'))
                        <span class="help-block">
                            <strong>{{ $errors->first('title') }}</strong>
                        </span>
                    @endif
				</div>
				
				<div class="form-group {{ $errors->has('featured') ? ' has-error' : '' }}">
					<label for="featured">Featured Image</label>
					<input  type="file" name="featured" class="form-control">
    	            @if ($errors->has('featured'))
                        <span class="help-block">
                            <strong>{{ $errors->first('featured') }}</strong>
                        </span>
                    @endif
				</div>
				
				<div class="form-group {{ $errors->has('category_id') ? ' has-error' : '' }}">
					<label for="category">Select Category</label>
					<select name="category_id" id="category" class="form-control cols-m-4">
						@foreach($categories as $category)
							<option value="{{ $category->id }}">{{ $category->name }}</option>
						@endforeach
					</select>
					@if ($errors->has('category_id'))
                        <span class="help-block">
                            <strong>{{ $errors->first('category_id') }}</strong>
                        </span>
                    @endif
				</div>
				
				
				<div class="form-group">
					<label for="tags">Select tags</label>
					@foreach ($tags as $tag)
					
                    	<div class="checkbox">
                            <label><input type="checkbox" name="tags[]" value="{{ $tag->id }}"> {{ $tag->tag }}</label>
                        </div>
                    
                    @endforeach
				</div>
				
				<div class="form-group {{ $errors->has('content') ? ' has-error' : '' }}">
					<label for="content">Content</label>
					<textarea name="content" id="content" rows="5" cols="5" class="form-control"></textarea>
					@if ($errors->has('content'))
                        <span class="help-block">
                            <strong>{{ $errors->first('content') }}</strong>
                        </span>
                    @endif
				</div>
				
				<div class="form-group">
					<div class="text-center">
						<button class="btn btn-success" type="submit">Store Post</button>
					</div>
				</div>
				
				
			</form>
		</div>
	
	</div>
@stop

@section('styles')
	<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
@endsection


@section('scripts')
	<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
	<script type="text/javascript">
    	$(document).ready(function() {
      		$('#content').summernote();
    	});
	</script>
@endsection