@extends('layouts.app')

@section('content')

	<div class="panel panel-default">
	
		<div class="panel-heading">
			Update category: {{ $category->name }}
		</div>
		
		<div class="panel-body">
		
			<form action="{{ route('category.update', ['id' => $category->id ])}}" method="POST">
				{{ csrf_field() }}
				
				<div class="form-group {{ $errors->has('name') ? ' has-error' : '' }}">
					<label for="name">Name</label>
					<input  type="text" name="name" value="{{ $category->name }}" class="form-control">
					@if ($errors->has('"name"'))
                        <span class="help-block">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
                    @endif
				</div>
				
				<div class="form-group">
					<div class="text-center">
						<button class="btn btn-success" type="submit">Update Category</button>
					</div>
				</div>
				
				
			</form>
		</div>
	
	</div>
@stop