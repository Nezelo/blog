@extends('layouts.app')

@section('left-side-navbar')
    <ul class="list-group">
        <li class="list-group-item">
    		<a href="#">Home</a>
    	</li>
    </ul>
@endsection