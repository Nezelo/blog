<?php $__env->startSection('content'); ?>

	<?php if(count($errors) > 0): ?>
	<?php endif; ?>
	<div class="panel panel-default">
	
		<div class="panel-heading">
			Create a new User
		</div>
		
		<div class="panel-body">
		
			<form action="<?php echo e(route('user.store')); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

				
				<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
					<label for="name">Name</label>
					<input  type="text" name="name" class="form-control">
					<?php if($errors->has('"name"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				
				<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
					<label for="name">Email</label>
					<input  type="email" name="email" class="form-control">
					<?php if($errors->has('"email"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				
				
				<div class="form-group">
					<div class="text-center">
						<button class="btn btn-success" type="submit">Add User</button>
					</div>
				</div>
				
				
			</form>
		</div>
	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>