<?php $__env->startSection('content'); ?>

<div class="col-lg-3">

	<div class="panel panel-info">
		<div class="panel-heading text-center">
			PUBLISHED POSTS
		</div>
		
		<div class="panel-body text-center">
			<h1 class="text-center"><?php echo e($post_cout); ?></h1>
		</div>
		
	</div>
	<div class="panel panel-danger">
		<div class="panel-heading text-center">
			TRASHED OSTS
		</div>
		
		<div class="panel-body text-center">
			<h1 class="text-center">8956</h1>
		</div>
		
	</div>
	<div class="panel panel-info">
		<div class="panel-heading text-center">
			CATEGORIES
		</div>
		
		<div class="panel-body text-center">
			<h1 class="text-center">8956</h1>
		</div>
		
	</div>
 
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>