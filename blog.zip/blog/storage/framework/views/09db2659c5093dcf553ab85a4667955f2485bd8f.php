<?php $__env->startSection('content'); ?>

	<?php if(count($errors) > 0): ?>
	<?php endif; ?>
	<div class="panel panel-default">
	
		<div class="panel-heading">
			Edit post: <?php echo e($post->title); ?>

		</div>
		
		<div class="panel-body">
		
			<form action="<?php echo e(route('post.update', ['id' => $post->id])); ?>" method="POST" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				<div class="form-group <?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
					<label for="title">Title</label>
					<input  type="text" name="title" class="form-control" value="<?php echo e($post->title); ?>">
					<?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				<div class="form-group <?php echo e($errors->has('featured') ? ' has-error' : ''); ?>">
					<label for="featured">Featured Image</label>
					<input  type="file" name="featured" class="form-control">
    	            <?php if($errors->has('featured')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('featured')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				<div class="form-group <?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
					<label for="category">Select Category</label>
					<select name="category_id" id="category" class="form-control cols-m-4">
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($category->id); ?>"
							
							<?php if($post->category->id == $category->id): ?>
								selected
							<?php endif; ?>
							><?php echo e($category->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<?php if($errors->has('category_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('category_id')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				<div class="form-group">
					<label for="tags">Select tags</label>
					<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
                    	<div class="checkbox">
                            <label><input type="checkbox" name="tags[]" value="<?php echo e($tag->id); ?>"
                            	<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            		<?php if($tag->id == $t->id): ?>
                            			checked
                            		<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            > <?php echo e($tag->tag); ?></label>
                        </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				
				
				<div class="form-group <?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
					<label for="content">Content</label>
					<textarea name="content" id="content" rows="5" cols="5" class="form-control"><?php echo e($post->content); ?></textarea>
					<?php if($errors->has('content')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('content')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				<div class="form-group">
					<div class="text-center">
						<button class="btn btn-success" type="submit">Update Post</button>
					</div>
				</div>
				
				
			</form>
		</div>
	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>