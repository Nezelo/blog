<?php $__env->startSection('content'); ?>

	<?php if(count($errors) > 0): ?>
	<?php endif; ?>
	<div class="panel panel-default">
	
		<div class="panel-heading">
			Edit your profile
		</div>
		
		<div class="panel-body">
		
			<form action="<?php echo e(route('user.profile.update')); ?>" method="POST" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
					<label for="name">Name</label>
					<input  type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
					<?php if($errors->has('"name"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				
				<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
					<label for="email">Email</label>
					<input  type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>">
					<?php if($errors->has('"email"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				
				<div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
					<label for="password">New Password</label>
					<input type="password" name="password" class="form-control">
					<?php if($errors->has('"password"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				
				<div class="form-group <?php echo e($errors->has('avatar') ? ' has-error' : ''); ?>">
					<label for="avatar">Upload Profile Picture</label>
					<input type="file" name="avatar" class="form-control">
					<?php if($errors->has('"avatar"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('avatar')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				
				<div class="form-group <?php echo e($errors->has('facebook') ? ' has-error' : ''); ?>">
					<label for="facebook">Facebook Profile</label>
					<input type="text" name="facebook" class="form-control" value="<?php echo e($user->profile->facebook); ?>">
					<?php if($errors->has('"facebook"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('facebook')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				
				<div class="form-group <?php echo e($errors->has('youtube') ? ' has-error' : ''); ?>">
					<label for="youtube">Youtube Profile</label>
					<input type="text" name="youtube" class="form-control" value="<?php echo e($user->profile->youtube); ?>">
					<?php if($errors->has('"youtube"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('youtube')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				
				<div class="form-group <?php echo e($errors->has('about') ? ' has-error' : ''); ?>">
					<label for="about">About</label>
					<textarea name="about" id="about" cols="6" rows="6" class="form-control" ><?php echo e($user->profile->about); ?></textarea>
					<?php if($errors->has('"about"')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('about')); ?></strong>
                        </span>
                    <?php endif; ?>
				</div>
				
				<div class="form-group">
					<div class="text-center">
						<button class="btn btn-success" type="submit">Update profile</button>
					</div>
				</div>
				
				
			</form>
		</div>
	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>